/*
 * fsm_manual.c
 *
 *  Created on: Oct 28, 2025
 *      Author: mtri1
 */
#include "fsm_manual.h"

void init_fsm_manual(){

}
void fsm_manual_run(){

}

