/*
 * fsm_manual.h
 *
 *  Created on: Oct 28, 2025
 *      Author: mtri1
 */

#ifndef INC_FSM_MANUAL_H_
#define INC_FSM_MANUAL_H_
#include "global.h"

void init_fsm_manual();
void fsm_manual_run();

#endif /* INC_FSM_MANUAL_H_ */
